## Tutorial-Taxi-Game

This is an open source demo game using Cocos Creator 3D v1.0.x, with 17 episodes of video tutorial on Bilibili. From this project, you can learn how to use Cocos Creator 3D to develop a 3D game from sratch.

- [17 episodes of video tutorials](https://space.bilibili.com/491120849/channel/detail?cid=116585)
- Download [Cocos Creator 3D](https://www.cocos.com/creator3d)

We appologize that the editor & video tutorial are only in Chinese today. Their English version are being developed, and will come out sooner.
